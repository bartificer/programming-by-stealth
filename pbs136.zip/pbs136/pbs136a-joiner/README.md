# The PBSJoiner Module

A module for joining lists of strings like a human would.

This module serves as an example in the [Programming by Stealth series](https://pbs.bartificer.net).