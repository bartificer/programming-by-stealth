# bartificer_ca.js
A JavaScript API for creating Cellular Automata
