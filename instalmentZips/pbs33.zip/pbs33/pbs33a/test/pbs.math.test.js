//
// === QUnit Tests for pbs.math API ==========================================
//

//
// -- General Tests --
//

// make sure our namespaces exist
QUnit.test('namespaces exist', function(assert){
	assert.expect(2);
	assert.ok(pbs, 'pbs namespace exists' );
	assert.ok(pbs.math, 'pbs.math namespace exists' );
});

//
// -- Function Tests (grouped) --
//

QUnit.module('pbs.math.factorial()', {}, function(){
	QUnit.test('function exists', function(assert){
		assert.strictEqual(typeof pbs.math.factorial, 'function', 'function exists');
	});
	
	QUnit.test('invalid arguments throw Errors', function(assert){
		assert.expect(9);
		assert.throws(
			function(){
				pbs.math.factorial();
			},
			Error,
			'throws Error when called without arguments'
		);
		assert.throws(
			function(){
				pbs.math.factorial('boogers');
			},
			Error,
			'throws Error when called with a string'
		);
		assert.throws(
			function(){
				pbs.math.factorial(true);
			},
			Error,
			'throws Error when called with a boolean'
		);
		assert.throws(
			function(){
				pbs.math.factorial({a: 'boogers'});
			},
			Error,
			'throws Error when called with a plain object'
		);
		assert.throws(
			function(){
				pbs.math.factorial(new Error('dummy'));
			},
			Error,
			'throws Error when called with a prototyped object'
		);
		assert.throws(
			function(){
				pbs.math.factorial([1, 2, 3]);
			},
			Error,
			'throws Error when called with an array object'
		);
		assert.throws(
			function(){
				pbs.math.factorial(function(){});
			},
			Error,
			'throws Error when called with a function object'
		);
		assert.throws(
			function(){
				pbs.math.factorial(Math.PI);
			},
			Error,
			'throws Error when called with a non-integer number'
		);
		assert.throws(
			function(){
				pbs.math.factorial(-42);
			},
			Error,
			'throws Error when called with a negative integer number'
		);
	});
	
	QUnit.test('inputs give expected outputs', function(assert){
		assert.expect(2);
		
		// check the lowest valid number
		assert.strictEqual(pbs.math.factorial(0), 1, 'the factorial of 0 is 1');
		
		// check a larger valid number
		assert.strictEqual(pbs.math.factorial(5), 120, 'the factorial of 5 is 120');
		
		// no maximum, so no need to test the upper bound of the valid range
	});
});

QUnit.module('pbs.math.fibonacciSeries()', {}, function(){
	QUnit.test('function exists', function(assert){
		assert.strictEqual(typeof pbs.math.fibonacciSeries, 'function', 'function exists');
	});
	
	QUnit.test('invalid arguments throw Errors', function(assert){
		assert.expect(7);
		assert.throws(
			function(){
				pbs.math.fibonacciSeries();
			},
			Error,
			'throws Error when called without arguments'
		);
		assert.throws(
			function(){
				pbs.math.fibonacciSeries('boogers');
			},
			Error,
			'throws Error when called with a string'
		);
		assert.throws(
			function(){
				pbs.math.fibonacciSeries(true);
			},
			Error,
			'throws Error when called with a boolean'
		);
		assert.throws(
			function(){
				pbs.math.fibonacciSeries({a: 'boogers'});
			},
			Error,
			'throws Error when called with a plain object'
		);
		assert.throws(
			function(){
				pbs.math.fibonacciSeries(new Error('dummy'));
			},
			Error,
			'throws Error when called with a prototyped object'
		);
		assert.throws(
			function(){
				pbs.math.fibonacciSeries([1, 2, 3]);
			},
			Error,
			'throws Error when called with an array object'
		);
		assert.throws(
			function(){
				pbs.math.fibonacciSeries(function(){});
			},
			Error,
			'throws Error when called with a function object'
		);
	});
	
	QUnit.test('inputs give expected outputs', function(assert){
		assert.expect(5);
		
		// check a number below zero - should return an empty array
		assert.deepEqual(pbs.math.fibonacciSeries(-42), [], '-42 evaluates to an empty array');
		
		// check that 0 returns [0] - we have implmented the modern alogrithm not the classical one
		assert.deepEqual(pbs.math.fibonacciSeries(0), [0], 'the series up to 0 evaluates to [0]');
		
		// check that 1 returns [0, 1] - the start of the classical algorythm
		assert.deepEqual(pbs.math.fibonacciSeries(1), [0, 1], 'the series up to 1 evaluates to [0, 1]');
		
		// check a larger valid number that is in the series
		assert.deepEqual(pbs.math.fibonacciSeries(8), [0, 1, 1, 2, 3, 5, 8], 'the series up to 8 is [0, 1, 1, 2, 3, 5, 8]');
		
		// check a larger valid number that is not in the series
		assert.deepEqual(pbs.math.fibonacciSeries(25.6), [0, 1, 1, 2, 3, 5, 8, 13, 21], 'the series up to 25.6 is [0, 1, 1, 2, 3, 5, 8, 13, 21]');
		
		// no maximum, so no need to test the upper bound of the valid range
	});
});