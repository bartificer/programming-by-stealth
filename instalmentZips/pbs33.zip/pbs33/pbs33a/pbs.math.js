// A simple API containing miscellaneous mathematical functions
// This is sample code from the Programming By Stealth series on www.bartb.ie,
// as such it is not intended for production use.

//
// === Initialise the pbs namespace ===========================================
//
var pbs = pbs ? pbs : {};

//
// === Wrap the API in a self-executing anonymous function ===
//
(function(pbs, undefined){
	//
	// -- initialise the pbs.math namespace
	//
	pbs.math = {};
	
	//
	// -- define the functions --
	//
	
	// -- Function --
	// Purpose    : Calcualte the factorial of a given number
	// Returns    : An integer
	// Arguments  : 1) an integer number >= 0
	// Throws     : Throws an Error on invalid arguments
	// Notes      :
	// See Also   : https://en.wikipedia.org/wiki/Factorial
	pbs.math.factorial = function(n){
		// validate and process args
		if(!arguments.length >= 1){
			throw new Error('first agument is required, and must be a positive integer (>= 0)');
		}
		if(!String(n).match(/^\d+$/)){
			throw new Error('invalid first argument - must be a positive integer (>= 0)');
		}
		var intN = parseInt(n); // force to typeof number
		
		// short-circuit the trivial answers
		if(intN == 0 || intN == 1){
			return 1;
		}
		
		// do the calculation
		var ans = intN;
		var ctr = intN - 1; // initialise a counter to one less than n
		while(ctr > 1){ // no point in multiplying anything by 1, hence > not >=
			ans *= ctr; // multiply the answer by the counter
			ctr--; // decrement the counter
		}
		
		// return the answer
		return ans;
	};
	
	// -- Function --
	// Purpose    : Calcualte the fibonacci series up to a given number
	// Returns    : An array of integers
	// Arguments  : 1) a number
	// Throws     : Throws an Error on invalid arguments
	// Notes      :
	// See Also   : https://en.wikipedia.org/wiki/Fibonacci_number
	pbs.math.fibonacciSeries = function(n){
		// validate and process args
		if(!arguments.length >= 1){
			throw new Error('first agument is required, and must be a positive integer (>= 0)');
		}
		if(typeof n !== 'number'){
			throw new Error('invalid first argument - must be a number');
		}
		
		// short-circuit the trivial values of the series so we can be sure there
		// are always two previous values to add together get the next value later
		if(n < 0){
			return [];
		}
		if(n < 1){
			return [0];
		}
		if(n < 2){
			return [0, 1];
		}
		
		// do the calculation
		var ans = [0, 1]; // start with the two seed values of the modern algorythm
		while(ans.slice(-1)[0] <= n){ // while the value of the last item in the ans array is <= n
			var lastTwo = ans.slice(-2);
			ans.push(lastTwo[0] + lastTwo[1]); // append the sum of the last two values to the ans array
		}
		
		// because we check before we calculate, we have gone one calculation too far,
		// so remove the last value from the array
		ans.pop();
		
		// return the answer
		return ans;
	};
})(pbs);