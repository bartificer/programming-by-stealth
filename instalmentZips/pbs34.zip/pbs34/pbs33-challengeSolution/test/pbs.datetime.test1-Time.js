//
//=== pbs.Time Tests ==========================================================
//
QUnit.module('pbs.Time prototype', {}, function(){
    // make sure the prototype exits
    QUnit.test('prototype exists', function(a){
        a.strictEqual(typeof pbs.Time, 'function', "pbs.Time has typeof 'function'");
    });
    
    // test cloning
    QUnit.test('cloning works', function(a){
        a.expect(3);
        var to = new pbs.Time(20, 10, 5);
        var tc = to.clone();
        a.notEqual(to, tc, 'clone is a true clone, not merely a reference');
        a.ok(tc instanceof pbs.Time, 'clone has correct prototype');
        a.propEqual(to, tc, 'all data properties the same in the original and clone');
    });
    
    //
    //--- pbs.Time Tests for the constructor and accessors --------------------
    //
    QUnit.module('constructor & accessors', {}, function(){
        
        QUnit.test('constructor defaults correctly', function(a){
            a.expect(3);
            var t = new pbs.Time();
            a.strictEqual(t._hours, 0, 'default hour is 0');
            a.strictEqual(t._minutes, 0, 'default minute is 0');
            a.strictEqual(t._seconds, 0, 'default seconds is 0');
        });
        
        QUnit.test('constructor sets values correctly', function(a){
            a.expect(6);
            
            // set with valid actual numbers
            var t1 = new pbs.Time(20, 10, 5);
            a.strictEqual(t1._hours, 20, 'hours set OK from integer number');
            a.strictEqual(t1._minutes, 10, 'minutes set OK from integer number');
            a.strictEqual(t1._seconds, 5, 'seconds set OK from integer number');
            
            // set with valid numbers as strings
            var t2 = new pbs.Time('21', '11', '6');
            a.strictEqual(t2._hours, 21, 'hours set OK from integer as string');
            a.strictEqual(t2._minutes, 11, 'minutes set OK from integer as string');
            a.strictEqual(t2._seconds, 6, 'seconds set OK from integer as string');
        });
        
        QUnit.test('accessors set correctly', function(a){
            a.expect(10);
            var t = new pbs.Time();
            
            // test setting hours
            t.hours(20);
            a.strictEqual(t._hours, 20, 'hours set OK from integer number');
            var th = t.hours('21');
            a.strictEqual(t._hours, 21, 'hours set OK from integer as string');
            a.equal(t, th, '.hours() returns a reference to self when setting');
            
            // test setting minutes
            t.minutes(10);
            a.strictEqual(t._minutes, 10, 'minutes set OK from integer number');
            var tm = t.minutes('11');
            a.strictEqual(t._minutes, 11, 'minutes set OK from integer as string');
            a.equal(t, tm, '.minutes() returns a reference to self when setting');
            
            // test setting seconds
            t.seconds(5);
            a.strictEqual(t._seconds, 5, 'seconds set OK from integer number');
            var ts = t.seconds('6');
            a.strictEqual(t._seconds, 6, 'seconds set OK from integer as string');
            a.equal(t, ts, '.seconds() returns a reference to self when setting');
            
            // test for side-effects
            a.ok(t._hours === 21 && t._minutes === 11 && t._seconds === 6, 'no unexpected side-effects');
        });
        
        QUnit.test('hours validation (via constructor & .hours() accessor)', function(a){
            // make sure all basic types except numbers throw
            var must_throw = dummyBasicTypesExcept('undef', 'num');
            a.expect((must_throw.length * 2) + 10);
            must_throw.forEach(function(tn){
                var basic_type = DUMMY_BASIC_TYPES[tn];
                a.throws(
                    function(){
                        var t = new pbs.Time(basic_type.val);
                    },
                    Error,
                    'constructor does not allow hours to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var t = new pbs.Time();
                        t.hours(basic_type.val);
                    },
                    Error,
                    'accessor .hours() does not allow hours to be ' + basic_type.desc
                );
            });
            
            // make sure invalid numbers throw
            a.throws(
                function(){
                    var t = new pbs.Time(Math.PI);
                },
                Error,
                'constructor does not allow hours to be non-integers'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.hours(Math.PI);
                },
                Error,
                'accessor .hours() does not allow hours to be non-integers'
            );
            a.throws(
                function(){
                    var t = new pbs.Time(-1);
                },
                Error,
                'constructor does not allow hours to be less than zero'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.hours(-1);
                },
                Error,
                'accessor .hours() does not allow hours to be less than zero'
            );
            a.throws(
                function(){
                    var t = new pbs.Time(24);
                },
                Error,
                'constructor does not allow hours to be greater than 23'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.hours(24);
                },
                Error,
                'accessor .hours() does not allow hours to be greater than 23'
            );
            
            // make sure valid extremes do not throw
            a.ok((function(){ var t = new pbs.Time(0); return true; })(), 'constructor allows hours 0 (min valid value)');
            a.ok((function(){ var t = new pbs.Time(); t.hours(0); return true; })(), '.hours() accessor allows hours 0 (min valid value)');
            a.ok((function(){ var t = new pbs.Time(23); return true; })(), 'constructor allows hours 23 (max valid value)');
            a.ok((function(){ var t = new pbs.Time(); t.hours(23); return true; })(), '.hours() accessor allows hours 23 (max valid value)');
        });
        
        QUnit.test('minutes validation (via constructor & .minutes() accessor)', function(a){
            // make sure all basic types except numbers throw
            var must_throw = dummyBasicTypesExcept('undef', 'num');
            a.expect((must_throw.length * 2) + 10);
            must_throw.forEach(function(tn){
                var basic_type = DUMMY_BASIC_TYPES[tn];
                a.throws(
                    function(){
                        var t = new pbs.Time(0, basic_type.val);
                    },
                    Error,
                    'constructor does not allow minutes to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var t = new pbs.Time();
                        t.minutes(basic_type.val);
                    },
                    Error,
                    'accessor .minutes() does not allow minutes to be ' + basic_type.desc
                );
            });
            
            // make sure invalid numbers throw
            a.throws(
                function(){
                    var t = new pbs.Time(0, Math.PI);
                },
                Error,
                'constructor does not allow minutes to be non-integers'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.minutes(Math.PI);
                },
                Error,
                'accessor .minutes() does not allow minutes to be non-integers'
            );
            a.throws(
                function(){
                    var t = new pbs.Time(0, -1);
                },
                Error,
                'constructor does not allow minutes to be less than zero'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.minutes(-1);
                },
                Error,
                'accessor .minutes() does not allow minutes to be less than zero'
            );
            a.throws(
                function(){
                    var t = new pbs.Time(0, 60);
                },
                Error,
                'constructor does not allow minutes to be greater than 59'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.minutes(60);
                },
                Error,
                'accessor .minutes() does not allow minutes to be greater than 59'
            );
            
            // make sure valid extremes do not throw
            a.ok((function(){ var t = new pbs.Time(0, 0); return true; })(), 'constructor allows minutes 0 (min valid value)');
            a.ok((function(){ var t = new pbs.Time(); t.minutes(0); return true; })(), '.minutes() accessor allows minutes 0 (min valid value)');
            a.ok((function(){ var t = new pbs.Time(0, 59); return true; })(), 'constructor allows minutes 59 (max valid value)');
            a.ok((function(){ var t = new pbs.Time(); t.minutes(59); return true; })(), '.minutes() accessor allows minutes 59 (max valid value)');
        });
        
        QUnit.test('seconds validation (via constructor & .seconds() accessor)', function(a){
            // make sure all basic types except numbers throw
            var must_throw = dummyBasicTypesExcept('undef', 'num');
            a.expect((must_throw.length * 2) + 10);
            must_throw.forEach(function(tn){
                var basic_type = DUMMY_BASIC_TYPES[tn];
                a.throws(
                    function(){
                        var t = new pbs.Time(0, 0, basic_type.val);
                    },
                    Error,
                    'constructor does not allow seconds to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var t = new pbs.Time();
                        t.seconds(basic_type.val);
                    },
                    Error,
                    'accessor .seconds() does not allow seconds to be ' + basic_type.desc
                );
            });
            
            // make sure invalid numbers throw
            a.throws(
                function(){
                    var t = new pbs.Time(0, 0, Math.PI);
                },
                Error,
                'constructor does not allow seconds to be non-integers'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.seconds(Math.PI);
                },
                Error,
                'accessor .seconds() does not allow seconds to be non-integers'
            );
            a.throws(
                function(){
                    var t = new pbs.Time(0, 0, -1);
                },
                Error,
                'constructor does not allow seconds to be less than zero'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.seconds(-1);
                },
                Error,
                'accessor .seconds() does not allow seconds to be less than zero'
            );
            a.throws(
                function(){
                    var t = new pbs.Time(0, 0, 60);
                },
                Error,
                'constructor does not allow seconds to be greater than 59'
            );
            a.throws(
                function(){
                    var t = new pbs.Time();
                    t.seconds(60);
                },
                Error,
                'accessor .seconds() does not allow seconds to be greater than 59'
            );
            
            // make sure valid extremes do not throw
            a.ok((function(){ var t = new pbs.Time(0, 0, 0); return true; })(), 'constructor allows seconds 0 (min valid value)');
            a.ok((function(){ var t = new pbs.Time(); t.seconds(0); return true; })(), '.seconds() accessor allows seconds 0 (min valid value)');
            a.ok((function(){ var t = new pbs.Time(0, 0, 59); return true; })(), 'constructor allows seconds 59 (max valid value)');
            a.ok((function(){ var t = new pbs.Time(); t.seconds(59); return true; })(), '.seconds() accessor allows seconds 59 (max valid value)');
        });
        
        QUnit.test('accessors successfully get', function(a){
            a.expect(3);
            
            var t = new pbs.Time(20, 10, 5);
            a.strictEqual(t.hours(), 20, '.hours() successfully gets');
            a.strictEqual(t.minutes(), 10, '.minutes() successfully gets');
            a.strictEqual(t.seconds(), 5, '.seconds() successfully gets');
        });
    });
    
    //
    //--- pbs.Time Tests for the string generation functions  -----------------
    //
    QUnit.module(
        'String Generation Functions',
        {
            before: function(){ // prep sample objects for use in all tests
                this.tmn = new pbs.Time(0, 0, 0);
                this.tam = new pbs.Time(3, 4, 5);    
                this.tn = new pbs.Time(12, 0, 0);
                this.tpm = new pbs.Time(15, 4, 5);
            }
        },
        function(){
            // test the basic toString()
            QUnit.test('.toString()', function(a){
                a.expect(4);
                a.equal(this.tmn.toString(), '00:00:00', 'Midnight renders correctly');
                a.equal(this.tam.toString(), '03:04:05', 'AM time renders correctly');
                a.equal(this.tn.toString(), '12:00:00', 'Noon renders correctly');
                a.equal(this.tpm.toString(), '15:04:05', 'PM time renders correctly');
            });
            
            // test the 12 hour format
            QUnit.test('.time12()', function(a){
                a.expect(4);
                a.equal(this.tmn.time12(), '12:00:00AM', 'Midnight renders correctly');
                a.equal(this.tam.time12(), '3:04:05AM', 'AM time renders correctly');
                a.equal(this.tn.time12(), '12:00:00PM', 'Noon renders correctly');
                a.equal(this.tpm.time12(), '3:04:05PM', 'PM time renders correctly');
            });
            
            // test the 24 hour format
            QUnit.test('.time24()', function(a){
                a.expect(4);
                a.equal(this.tmn.time24(), '00:00:00', 'Midnight renders correctly');
                a.equal(this.tam.time24(), '03:04:05', 'AM time renders correctly');
                a.equal(this.tn.time24(), '12:00:00', 'Noon renders correctly');
                a.equal(this.tpm.time24(), '15:04:05', 'PM time renders correctly');
            });
        }
    );
    
    //
    //--- pbs.Time Tests for the comparison functions  ------------------------
    //
    QUnit.module(
        'Comparison Functions',
        {
            before: function(){ // prep sample objects for use in all tests
                this.t0 = new pbs.Time(3, 4, 5);
                this.t1 = new pbs.Time(3, 4, 5);
                this.t2 = new pbs.Time(3, 4, 6);    
                this.t3 = new pbs.Time(3, 5, 5);
                this.t4 = new pbs.Time(4, 4, 4);
            }
        },
        function(){
            // test basic .equals()
            QUnit.test('.equals()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(dtp){
                    a.strictEqual(that.t0.equals(DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' returns false');
                });
                a.strictEqual(this.t0.equals(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Time returns false');
                
                // test with legal input
                a.strictEqual(this.t0.equals(this.t1), true, 'equal times return true');
                a.strictEqual(this.t1.equals(this.t2), false, 'earlier to later returns false');
                a.strictEqual(this.t4.equals(this.t3), false, 'later to earlier returns false');
            });
            
            // test static pbs.Time.areEqual()
            QUnit.test('pbs.Time.areEqual()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect((mustBeFalse.length * 3) + 8);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(dtp){
                    a.strictEqual(pbs.Time.areEqual(DUMMY_DATA[dtp].val, that.t1), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as first argument returns false');
                    a.strictEqual(pbs.Time.areEqual(that.t1, DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as second argument returns false');
                    a.strictEqual(pbs.Time.areEqual(that.t0, that.t1, DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as third argument returns false');
                });
                a.strictEqual(pbs.Time.areEqual(DUMMY_DATA.obj_proto.val, this.t1), false, 'calling with a prototyped object that does not have the prototype pbs.Time as the first argumemt returns false');
                a.strictEqual(pbs.Time.areEqual(this.t1, DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Time as the second argumemt returns false');
                a.strictEqual(pbs.Time.areEqual(this.t0, this.t1, DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Time as the third argumemt returns false');
                
                // test with legal inputs
                a.strictEqual(pbs.Time.areEqual(this.t0, this.t1), true, 'two equal times returns true');
                a.strictEqual(pbs.Time.areEqual(this.t0, this.t1, this.t1.clone()), true, 'three equal times returns true');
                a.strictEqual(pbs.Time.areEqual(this.t1, this.t2), false, 'two different times returns false');
                a.strictEqual(pbs.Time.areEqual(this.t0, this.t1, this.t2), false, 'two equal times and a different time returns false');
                a.strictEqual(pbs.Time.areEqual(this.t1, this.t2, this.t3), false, 'three different times returns false');
            });
            
            // test .compareTo()
            QUnit.test('.compareTo()', function(a){
                // collect references to all the types that must return NaN
                var mustBeNaN = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeNaN.length + 4);
                
                // test with bogus input
                var that = this;
                mustBeNaN.sort().forEach(function(tn){
                    a.ok(isNaN(that.t1.compareTo(DUMMY_DATA[tn].val)), 'comparing to ' + DUMMY_DATA[tn].desc + ' returns NaN');
                });
                a.ok(isNaN(that.t1.compareTo(DUMMY_DATA.obj_proto.val)), 'comparing to object with prototype other than pbs.Time returns NaN');
                
                // test with legal inputs
                a.strictEqual(this.t0.compareTo(this.t1), 0, 'equal times return 0');
                a.strictEqual(this.t1.compareTo(this.t2), -1, 'earlier to later returns -1');
                a.strictEqual(this.t4.compareTo(this.t3), 1, 'later to earlier returns 1');
            });
            
            // test .isBefore()
            QUnit.test('.isBefore()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(tn){
                    a.strictEqual(that.t0.isBefore(DUMMY_DATA[tn].val), false, 'calling with ' + DUMMY_DATA[tn].desc + ' returns false');
                });
                a.strictEqual(this.t0.isBefore(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Time returns false');
                
                // test with legal inputs
                a.strictEqual(this.t0.isBefore(this.t1), false, 'equal times return false');
                a.strictEqual(this.t1.isBefore(this.t2), true, 'earlier to later returns true');
                a.strictEqual(this.t4.isBefore(this.t3), false, 'later to earlier returns false');
            });
            
            // test .isAfter()
            QUnit.test('.isAfter()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(tn){
                    a.strictEqual(that.t0.isAfter(DUMMY_DATA[tn].val), false, 'calling with ' + DUMMY_DATA[tn].desc + ' returns false');
                });
                a.strictEqual(this.t0.isAfter(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Time returns false');
                
                // test with legal inputs
                a.strictEqual(this.t0.isAfter(this.t1), false, 'equal times return false');
                a.strictEqual(this.t1.isAfter(this.t2), false, 'earlier to later returns false');
                a.strictEqual(this.t4.isAfter(this.t3), true, 'later to earlier returns true');
            });
        }
    );
});