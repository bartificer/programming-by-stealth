//
//=== pbs.DateTime Tests ==========================================================
//
QUnit.module('pbs.DateTime prototype', {}, function(){
    // make sure the prototype exits
    QUnit.test('prototype exists', function(a){
        a.strictEqual(typeof pbs.DateTime, 'function', "pbs.DateTime has typeof 'function'");
    });
    
    // test cloning
    QUnit.test('cloning works', function(a){
        a.expect(3);
        var dto = new pbs.DateTime(new pbs.Date(2000, 10, 5), new pbs.Time(20, 10, 5));
        var dtc = dto.clone();
        a.notEqual(dto, dtc, 'clone is a true clone, not merely a reference');
        a.ok(dtc instanceof pbs.DateTime, 'clone has correct prototype');
        a.propEqual(dto, dtc, 'all data properties the same in the original and clone');
    });
    
    //
    //--- pbs.Time Tests for the constructor and accessors --------------------
    //
    QUnit.module(
        'constructor & accessors',
        {
            before: function(){ // prep sample objects for use in all tests
                this.d = new pbs.Date(2000, 10, 5);
                this.t = new pbs.Time(20, 10, 5);
            }
        },
        function(){
            QUnit.test('constructor defaults correctly', function(a){
                a.expect(2);
                var dt = new pbs.DateTime();
                a.ok(dt._date instanceof pbs.Date, 'default date has expected prototype');
                a.ok(dt._time instanceof pbs.Time, 'default time has expected prototype');
            });
        
            QUnit.test('constructor sets values correctly', function(a){
                a.expect(4);
                var dt = new pbs.DateTime(this.d, this.t);
                a.ok(this.d.equals(dt._date), 'stored date has the correct value');
                a.notEqual(this.d, dt._date, 'stored date is a clone not a reference');
                a.ok(this.t.equals(dt._time), 'stored time has the correct value');
                a.notEqual(this.t, dt._time, 'stored time is a clone not a reference');
            });
        
            QUnit.test('accessors set correctly', function(a){
                a.expect(4);
                var dt = new pbs.DateTime();
            
                // test setting date
                dt.date(this.d);
                a.ok(this.d.equals(dt._date), 'stored date has the correct value');
                a.notEqual(this.d, dt._date, 'stored date is a clone not a reference');
                
                // test setting time
                dt.time(this.t);
                a.ok(this.t.equals(dt._time), 'stored time has the correct value');
                a.notEqual(this.t, dt._time, 'stored time is a clone not a reference');
            });
            
            QUnit.test('date validation (via constructor & .date() accessor)', function(a){
                // make sure all basic types except undefuned throw
                var must_throw = dummyBasicTypesExcept('undef');
                must_throw.push('obj_proto'); // make sure generic prototyped objects throw
                a.expect((must_throw.length * 2) + 2);
                must_throw.forEach(function(tn){
                    var basic_type = DUMMY_DATA[tn];
                    a.throws(
                        function(){
                            var dt = new pbs.DateTime(basic_type.val);
                        },
                        Error,
                        'constructor does not allow date to be ' + basic_type.desc
                    );
                    a.throws(
                        function(){
                            var dt = new pbs.DateTime();
                            dt.date(basic_type.val);
                        },
                        Error,
                        'accessor .date() does not allow date to be ' + basic_type.desc
                    );
                });
                
                // make sure a properly prototyped object does not throw
                var that = this;
                a.ok((function(){ var dt = new pbs.DateTime(that.d); return true; })(), 'constructor allows date to be set to object with prototype pbs.Date');
                a.ok((function(){ var dt = new pbs.DateTime(); dt.date(that.d); return true; })(), '.date() accessor allows date to be set to object with prototype pbs.Date');
            });
            
            QUnit.test('time validation (via constructor & .time() accessor)', function(a){
                // make sure all basic types except undefuned throw
                var must_throw = dummyBasicTypesExcept('undef');
                must_throw.push('obj_proto'); // make sure generic prototyped objects throw
                a.expect((must_throw.length * 2) + 2);
                must_throw.forEach(function(tn){
                    var basic_type = DUMMY_DATA[tn];
                    a.throws(
                        function(){
                            var dt = new pbs.DateTime(undefined, basic_type.val);
                        },
                        Error,
                        'constructor does not allow time to be ' + basic_type.desc
                    );
                    a.throws(
                        function(){
                            var dt = new pbs.DateTime();
                            dt.time(basic_type.val);
                        },
                        Error,
                        'accessor .time() does not allow date to be ' + basic_type.desc
                    );
                });
                
                // make sure a properly prototyped object does not throw
                var that = this;
                a.ok((function(){ var dt = new pbs.DateTime(undefined, that.t); return true; })(), 'constructor allows time to be set to object with prototype pbs.Time');
                a.ok((function(){ var dt = new pbs.DateTime(); dt.time(that.t); return true; })(), '.time() accessor allows time to be set to object with prototype pbs.Time');
            });
        }
    );
    
    //
    //--- pbs.Date Tests for the string generation functions  -----------------
    //
    QUnit.module(
        'String Generation Functions',
        {
            before: function(){ // prep sample objects for use in all tests
                this.dt = new pbs.DateTime(new pbs.Date(2000, 10, 5), new pbs.Time(20, 10, 5));
                this.dtfm = new pbs.DateTime(new pbs.Date(200, 10, 5), new pbs.Time(20, 10, 5));
                this.dty0 = new pbs.DateTime(new pbs.Date(0, 10, 5), new pbs.Time(20, 10, 5));
                this.dtbce = new pbs.DateTime(new pbs.Date(-20, 10, 5), new pbs.Time(20, 10, 5));
            }
        },
        function(){
            QUnit.test('.toString()', function(a){
                a.expect(4);
                a.equal(this.dt.toString(), '2000-10-05 20:10:05', 'ordinary DateTime renders correctly');
                a.equal(this.dtfm.toString(), '0200-10-05 20:10:05', 'first-millenium DateTime renders correctly');
                a.equal(this.dty0.toString(), '0000-10-05 20:10:05', 'year zero DateTime renders correctly');
                a.equal(this.dtbce.toString(), '-0020-10-05 20:10:05', 'BCE DateTime renders correctly');
            });
            
            QUnit.test('.american12Hour()', function(a){
                a.expect(4);
                a.equal(this.dt.american12Hour(), '10/5/2000 8:10:05PM', 'ordinary DateTime renders correctly');
                a.equal(this.dtfm.american12Hour(), '10/5/200 8:10:05PM', 'first-millenium DateTime renders correctly');
                a.equal(this.dty0.american12Hour(), '10/5/1BC 8:10:05PM', 'year zero DateTime renders correctly');
                a.equal(this.dtbce.american12Hour(), '10/5/21BC 8:10:05PM', 'BCE DateTime renders correctly');
            });
            
            QUnit.test('.american24Hour()', function(a){
                a.expect(4);
                a.equal(this.dt.american24Hour(), '10/5/2000 20:10:05', 'ordinary DateTime renders correctly');
                a.equal(this.dtfm.american24Hour(), '10/5/200 20:10:05', 'first-millenium DateTime renders correctly');
                a.equal(this.dty0.american24Hour(), '10/5/1BC 20:10:05', 'year zero DateTime renders correctly');
                a.equal(this.dtbce.american24Hour(), '10/5/21BC 20:10:05', 'BCE DateTime renders correctly');
            });
            
            QUnit.test('.european12Hour()', function(a){
                a.expect(4);
                a.equal(this.dt.european12Hour(), '05-10-2000 8:10:05PM', 'ordinary DateTime renders correctly');
                a.equal(this.dtfm.european12Hour(), '05-10-200 8:10:05PM', 'first-millenium DateTime renders correctly');
                a.equal(this.dty0.european12Hour(), '05-10-1BCE 8:10:05PM', 'year zero DateTime renders correctly');
                a.equal(this.dtbce.european12Hour(), '05-10-21BCE 8:10:05PM', 'BCE DateTime renders correctly');
            });
            
            QUnit.test('.european24Hour()', function(a){
                a.expect(4);
                a.equal(this.dt.european24Hour(), '05-10-2000 20:10:05', 'ordinary DateTime renders correctly');
                a.equal(this.dtfm.european24Hour(), '05-10-200 20:10:05', 'first-millenium DateTime renders correctly');
                a.equal(this.dty0.european24Hour(), '05-10-1BCE 20:10:05', 'year zero DateTime renders correctly');
                a.equal(this.dtbce.european24Hour(), '05-10-21BCE 20:10:05', 'BCE DateTime renders correctly');
            });
        }
    );
    
    //
    //--- pbs.DateTime Tests for the comparison functions  --------------------
    //
    QUnit.module(
        'Comparison Functions',
        {
            before: function(){ // prep sample objects for use in all tests
                this.dt0 = new pbs.DateTime(new pbs.Date(2000, 10, 5), new pbs.Time(3, 4, 5));
                this.dt1 = new pbs.DateTime(new pbs.Date(2000, 10, 5), new pbs.Time(3, 4, 5));
                this.dt2 = new pbs.DateTime(new pbs.Date(2000, 10, 5), new pbs.Time(3, 4, 6));
                this.dt3 = new pbs.DateTime(new pbs.Date(2000, 10, 6), new pbs.Time(3, 4, 4));
                this.dt4 = new pbs.DateTime(new pbs.Date(2000, 11, 4), new pbs.Time(3, 4, 5));
            }
        },
        function(){
            // test basic .equals()
            QUnit.test('.equals()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(dtp){
                    a.strictEqual(that.dt0.equals(DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' returns false');
                });
                a.strictEqual(this.dt0.equals(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.DateTime returns false');
                
                // test with legal input
                a.strictEqual(this.dt0.equals(this.dt1), true, 'equal DateTimes return true');
                a.strictEqual(this.dt1.equals(this.dt2), false, 'earlier to later returns false');
                a.strictEqual(this.dt4.equals(this.dt3), false, 'later to earlier returns false');
            });
            
            // test static pbs.Time.areEqual()
            QUnit.test('pbs.DateTime.areEqual()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect((mustBeFalse.length * 3) + 8);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(dtp){
                    a.strictEqual(pbs.DateTime.areEqual(DUMMY_DATA[dtp].val, that.dt1), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as first argument returns false');
                    a.strictEqual(pbs.DateTime.areEqual(that.dt1, DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as second argument returns false');
                    a.strictEqual(pbs.DateTime.areEqual(that.dt0, that.dt1, DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as third argument returns false');
                });
                a.strictEqual(pbs.DateTime.areEqual(DUMMY_DATA.obj_proto.val, this.dt1), false, 'calling with a prototyped object that does not have the prototype pbs.DateTime as the first argumemt returns false');
                a.strictEqual(pbs.DateTime.areEqual(this.dt1, DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.DateTime as the second argumemt returns false');
                a.strictEqual(pbs.DateTime.areEqual(this.dt0, this.dt1, DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.DateTime as the third argumemt returns false');
                
                // test with legal inputs
                a.strictEqual(pbs.DateTime.areEqual(this.dt0, this.dt1), true, 'two equal DateTimes returns true');
                a.strictEqual(pbs.DateTime.areEqual(this.dt0, this.dt1, this.dt1.clone()), true, 'three equal DateTimes returns true');
                a.strictEqual(pbs.DateTime.areEqual(this.dt1, this.dt2), false, 'two different DateTimes returns false');
                a.strictEqual(pbs.DateTime.areEqual(this.dt0, this.dt1, this.dt2), false, 'two equal DateTimes and a different DateTime returns false');
                a.strictEqual(pbs.DateTime.areEqual(this.dt1, this.dt2, this.dt3), false, 'three different DateTimes returns false');
            });
            
            // test .compareTo()
            QUnit.test('.compareTo()', function(a){
                // collect references to all the types that must return NaN
                var mustBeNaN = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeNaN.length + 4);
                
                // test with bogus input
                var that = this;
                mustBeNaN.sort().forEach(function(tn){
                    a.ok(isNaN(that.dt1.compareTo(DUMMY_DATA[tn].val)), 'comparing to ' + DUMMY_DATA[tn].desc + ' returns NaN');
                });
                a.ok(isNaN(that.dt1.compareTo(DUMMY_DATA.obj_proto.val)), 'comparing to object with prototype other than pbs.Time returns NaN');
                
                // test with legal inputs
                a.strictEqual(this.dt0.compareTo(this.dt1), 0, 'equal DateTimes return 0');
                a.strictEqual(this.dt1.compareTo(this.dt2), -1, 'earlier to later returns -1');
                a.strictEqual(this.dt4.compareTo(this.dt3), 1, 'later to earlier returns 1');
            });
            
            // test .isBefore()
            QUnit.test('.isBefore()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(tn){
                    a.strictEqual(that.dt0.isBefore(DUMMY_DATA[tn].val), false, 'calling with ' + DUMMY_DATA[tn].desc + ' returns false');
                });
                a.strictEqual(this.dt0.isBefore(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.DateTime returns false');
                
                // test with legal inputs
                a.strictEqual(this.dt0.isBefore(this.dt1), false, 'equal DateTimes return false');
                a.strictEqual(this.dt1.isBefore(this.dt2), true, 'earlier to later returns true');
                a.strictEqual(this.dt4.isBefore(this.dt3), false, 'later to earlier returns false');
            });
            
            // test .isAfter()
            QUnit.test('.isAfter()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(tn){
                    a.strictEqual(that.dt0.isAfter(DUMMY_DATA[tn].val), false, 'calling with ' + DUMMY_DATA[tn].desc + ' returns false');
                });
                a.strictEqual(this.dt0.isAfter(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.DateTime returns false');
                
                // test with legal inputs
                a.strictEqual(this.dt0.isAfter(this.dt1), false, 'equal DateTimes return false');
                a.strictEqual(this.dt1.isAfter(this.dt2), false, 'earlier to later returns false');
                a.strictEqual(this.dt4.isAfter(this.dt3), true, 'later to earlier returns true');
            });
        }
    );
});