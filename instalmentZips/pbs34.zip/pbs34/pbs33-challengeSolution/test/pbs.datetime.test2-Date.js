//
//=== pbs.Time Tests ==========================================================
//
QUnit.module('pbs.Date prototype', {}, function(){
    // make sure the prototype exits
    QUnit.test('prototype exists', function(a){
        a.strictEqual(typeof pbs.Date, 'function', "pbs.Date has typeof 'function'");
    });
    
    // test cloning
    QUnit.test('cloning works', function(a){
        a.expect(3);
        var d0 = new pbs.Date(2000, 10, 5);
        var dc = d0.clone();
        a.notEqual(d0, dc, 'clone is a true clone, not merely a reference');
        a.ok(dc instanceof pbs.Date, 'clone has correct prototype');
        a.propEqual(d0, dc, 'all data properties the same in the original and clone');
    });
    
    //
    //--- pbs.Time Tests for the constructor and accessors --------------------
    //
    QUnit.module('constructor & accessors', {}, function(){
        
        QUnit.test('constructor defaults correctly', function(a){
            a.expect(3);
            var d = new pbs.Date();
            a.strictEqual(d._year, 1970, 'default year is 1970');
            a.strictEqual(d._month, 1, 'default month is 1');
            a.strictEqual(d._day, 1, 'default seconds is 1');
        });
        
        QUnit.test('constructor sets values correctly', function(a){
            a.expect(6);
            
            // set with valid actual numbers
            var d1 = new pbs.Date(2000, 10, 5);
            a.strictEqual(d1._year, 2000, 'year set OK from integer number');
            a.strictEqual(d1._month, 10, 'month set OK from integer number');
            a.strictEqual(d1._day, 5, 'day set OK from integer number');
            
            // set with valid numbers as strings
            var d2 = new pbs.Date('2001', '11', '6');
            a.strictEqual(d2._year, 2001, 'year set OK from integer as string');
            a.strictEqual(d2._month, 11, 'month set OK from integer as string');
            a.strictEqual(d2._day, 6, 'day set OK from integer as string');
        });
        
        QUnit.test('accessors set correctly', function(a){
            a.expect(10);
            var d = new pbs.Date();
            
            // test setting year
            d.year(2000);
            a.strictEqual(d._year, 2000, 'year set OK from integer number');
            var dy = d.year('2001');
            a.strictEqual(d._year, 2001, 'year set OK from integer as string');
            a.equal(d, dy, '.year() returns a reference to self when setting');
            
            // test setting month
            d.month(10);
            a.strictEqual(d._month, 10, 'month set OK from integer number');
            var dm = d.month('11');
            a.strictEqual(d._month, 11, 'month set OK from integer as string');
            a.equal(d, dm, '.month() returns a reference to self when setting');
            
            // test setting day
            d.day(5);
            a.strictEqual(d._day, 5, 'day set OK from integer number');
            var dd = d.day('6');
            a.strictEqual(d._day, 6, 'day set OK from integer as string');
            a.equal(d, dd, '.day() returns a reference to self when setting');
            
            // test for side-effects
            a.ok(d._year === 2001 && d._month === 11 && d._day === 6, 'no unexpected side-effects');
        });
        
        QUnit.test('year validation (via constructor & accessors)', function(a){
            // make sure all basic types except numbers throw
            var must_throw = dummyBasicTypesExcept('undef', 'num');
            a.expect((must_throw.length * 5) + 2);
            must_throw.forEach(function(tn){
                var basic_type = DUMMY_BASIC_TYPES[tn];
                a.throws(
                    function(){
                        var d = new pbs.Date(basic_type.val);
                    },
                    Error,
                    'constructor does not allow year to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.year(basic_type.val);
                    },
                    Error,
                    'accessor .year() does not allow year to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.international(basic_type.val, 1, 1);
                    },
                    Error,
                    'accessor .international() does not allow year to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.american(1, 1, basic_type.val);
                    },
                    Error,
                    'accessor .american() does not allow year to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.european(1, 1, basic_type.val);
                    },
                    Error,
                    'accessor .european() does not allow year to be ' + basic_type.desc
                );
            });
            
            // make sure invalid numbers throw
            a.throws(
                function(){
                    var d = new pbs.Date(Math.PI);
                },
                Error,
                'constructor does not allow year to be non-integer'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.year(Math.PI);
                },
                Error,
                'accessor .year() does not allow year to be non-integer'
            );			
        });
        
        QUnit.test('month validation (via constructor & accessors)', function(a){
            // make sure all basic types except numbers throw
            var must_throw = dummyBasicTypesExcept('undef', 'num');
            a.expect((must_throw.length * 5) + 10);
            must_throw.forEach(function(tn){
                var basic_type = DUMMY_BASIC_TYPES[tn];
                a.throws(
                    function(){
                        var d = new pbs.Date(undefined, basic_type.val);
                    },
                    Error,
                    'constructor does not allow month to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.month(basic_type.val);
                    },
                    Error,
                    'accessor .month() does not allow month to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.international(2000, basic_type.val, 1);
                    },
                    Error,
                    'accessor .international() does not allow month to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.american(basic_type.val, 1, 2000);
                    },
                    Error,
                    'accessor .american() does not allow month to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.european(1, basic_type.val, 2000);
                    },
                    Error,
                    'accessor .european() does not allow month to be ' + basic_type.desc
                );
            });
            
            // make sure invalid numbers throw
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, Math.PI);
                },
                Error,
                'constructor does not allow month to be non-integers'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.month(Math.PI);
                },
                Error,
                'accessor .month() does not allow month to be non-integer'
            );
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, 0);
                },
                Error,
                'constructor does not allow month to be less than one'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.month(0);
                },
                Error,
                'accessor .month() does not allow month to be less than one'
            );
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, 13);
                },
                Error,
                'constructor does not allow month to be greater than 12'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.month(13);
                },
                Error,
                'accessor .month() does not allow month to be greater than 12'
            );
            
            // make sure valid extremes do not throw
            a.ok((function(){ var d = new pbs.Date(undefined, 1); return true; })(), 'constructor allows month 1 (min valid value)');
            a.ok((function(){ var d = new pbs.Date(); d.month(1); return true; })(), '.month() accessor allows month 1 (min valid value)');
            a.ok((function(){ var d = new pbs.Date(undefined, 12); return true; })(), 'constructor allows month 12 (max valid value)');
            a.ok((function(){ var d = new pbs.Date(); d.month(12); return true; })(), '.month() accessor allows month 12 (max valid value)');
        });
        
        QUnit.test('day validation (via constructor & accessors)', function(a){
            // make sure all basic types except numbers throw
            var must_throw = dummyBasicTypesExcept('undef', 'num');
            a.expect((must_throw.length * 5) + 37);
            must_throw.forEach(function(tn){
                var basic_type = DUMMY_BASIC_TYPES[tn];
                a.throws(
                    function(){
                        var d = new pbs.Date(undefined, undefined, basic_type.val);
                    },
                    Error,
                    'constructor does not allow day to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.day(basic_type.val);
                    },
                    Error,
                    'accessor .day() does not allow day to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.international(2000, 1, basic_type.val);
                    },
                    Error,
                    'accessor .international() does not allow day to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.american(1, basic_type.val, 2000);
                    },
                    Error,
                    'accessor .american() does not allow day to be ' + basic_type.desc
                );
                a.throws(
                    function(){
                        var d = new pbs.Date();
                        d.european(basic_type.val, 1, 2000);
                    },
                    Error,
                    'accessor .european() does not allow day to be ' + basic_type.desc
                );
            });
            
            // make sure invalid numbers throw
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, undefined, Math.PI);
                },
                Error,
                'constructor does not allow day to be non-integer'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.day(Math.PI);
                },
                Error,
                'accessor .day() does not allow day to be non-integer'
            );
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, undefined, 0);
                },
                Error,
                'constructor does not allow day to be less than one'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.day(0);
                },
                Error,
                'accessor .day() does not allow day to be less than one'
            );
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, undefined, 32);
                },
                Error,
                'constructor does not allow day to be greater than 31'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.day(32);
                },
                Error,
                'accessor .day() does not allow day to be greater than 31'
            );
            
            // -- make sure valid extremes do not throw --
            
            // start with the easy part, that 1 does not through
            a.ok((function(){ var d = new pbs.Date(undefined, undefined, 1); return true; })(), 'constructor allows day 1 (min valid value)');
            a.ok((function(){ var d = new pbs.Date(); d.day(1); return true; })(), '.day() accessor allows day 1 (min valid value)');
            
            // next deal with the months other than february
            var monthData = {};
            monthData[1] = {
                name: 'Jan',
                max: 31,
            };
            monthData[3] = {
                name: 'Mar',
                max: 31,
            };
            monthData[4] = {
                name: 'Apr',
                max: 30,
            };
            monthData[5] = {
                name: 'May',
                max: 31,
            };
            monthData[6] = {
                name: 'Jun',
                max: 30,
            };
            monthData[7] = {
                name: 'Jul',
                max: 31,
            };
            monthData[8] = {
                name: 'Aug',
                max: 31,
            };
            monthData[9] = {
                name: 'Sep',
                max: 30,
            };
            monthData[10] = {
                name: 'Oct',
                max: 31,
            };
            monthData[11] = {
                name: 'Nov',
                max: 30,
            };
            monthData[12] = {
                name: 'Dec',
                max: 31,
            };
            Object.keys(monthData).sort().forEach(function(mi){
                a.ok(
                    (function(){
                        var d = new pbs.Date(undefined, mi, monthData[mi].max);
                        return true;
                    })(),
                    'constructor allows day ' + mi + ' for ' + monthData[mi].name + ' (max valid value)'
                );
                if(monthData[mi].max === 30){
                    a.throws(
                        function(){
                            var d = new pbs.Date(undefined, mi, 31);
                        },
                        Error,
                        'constructor does not allow day to be greater than 30 for ' + monthData[mi].name
                    );
                    a.throws(
                        function(){
                            var d = new pbs.Date();
                            d.month(mi);
                            d.day(31);
                        },
                        Error,
                        'accessor .day() does not allow day to be greater than 30 for ' + monthData[mi].name
                    );
                }            
            });
            
            // deal with February
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, 2, 31);
                },
                Error,
                'constructor does not allow day to be 31 for Feb'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.month(mi);
                    d.day(31);
                },
                Error,
                'accessor .day() does not allow day to be 31 for Feb'
            );
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, 2, 30);
                },
                Error,
                'constructor does not allow day to be 30 for Feb'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.month(mi);
                    d.day(30);
                },
                Error,
                'accessor .day() does not allow day to be 30 for Feb'
            );
            
            a.ok((function(){ var d = new pbs.Date(2001, 2, 28); return true; })(), 'constructor allows Feb 28 on a non-leap-year  (max valid value)');
            a.ok((function(){ var d = new pbs.Date(2001, 2); d.day(28); return true; })(), '.day() accessor allows 28 Feb on a no-leap-year (max valid value)');
            a.throws(
                function(){
                    var d = new pbs.Date(undefined, 2, 30);
                },
                Error,
                'constructor does not allow day to be 30 for Feb'
            );
            a.throws(
                function(){
                    var d = new pbs.Date(2001, 2);
                    d.day(29);
                },
                Error,
                'accessor .day() does not allow Feb 29 on a non-leap-year'
            );
            a.ok((function(){ var d = new pbs.Date(2004, 2, 29); return true; })(), 'constructor allows Feb 29 on a leap-year  (max valid value)');
            a.ok((function(){ var d = new pbs.Date(2004, 2); d.day(29); return true; })(), '.day() accessor allows 29 Feb on a leap-year (max valid value)');
        });
        
        QUnit.test('accessors successfully get', function(a){
            a.expect(3);
            
            var d = new pbs.Date(2000, 10, 5);
            a.strictEqual(d.year(), 2000, '.year() successfully gets');
            a.strictEqual(d.month(), 10, '.month() successfully gets');
            a.strictEqual(d.day(), 5, '.day() successfully gets');
        });
        
        QUnit.test('multi-value setters set correctly', function(a){
            a.expect(15);
            
            // check .internatinoal() sets correctly
            var d1 = new pbs.Date();
            var d1a = d1.international(2000, 10, 5);
            a.strictEqual(d1._year, 2000, '.internationa() correctly sets year');
            a.strictEqual(d1._month, 10, '.internationa() correctly sets month');
            a.strictEqual(d1._day, 5, '.internationa() correctly sets day');
            a.equal(d1, d1a, '.international() returns reference to self when setting');
            
            // check .american() sets correctly
            var d2 = new pbs.Date();
            var d2a = d2.american(10, 5, 2000);
            a.strictEqual(d2._year, 2000, '.american() correctly sets year');
            a.strictEqual(d2._month, 10, '.american() correctly sets month');
            a.strictEqual(d2._day, 5, '.american() correctly sets day');
            a.equal(d2, d2a, '.american() returns reference to self when setting');
            
            // check .european() sets correctly
            var d3 = new pbs.Date();
            var d3a = d3.european(5, 10, 2000);
            a.strictEqual(d3._year, 2000, '.european() correctly sets year');
            a.strictEqual(d3._month, 10, '.european() correctly sets month');
            a.strictEqual(d3._day, 5, '.european() correctly sets day');
            a.equal(d3, d3a, '.european() returns reference to self when setting');
            
            // test all three fail to set impossible dates
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.international(2000, 4, 31);
                },
                Error,
                '.international() does not allow setting of impossible dates'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.american(4, 31, 2000);
                },
                Error,
                '.american() does not allow setting of impossible dates'
            );
            a.throws(
                function(){
                    var d = new pbs.Date();
                    d.european(31, 4, 2000);
                },
                Error,
                '.european() does not allow setting of impossible dates'
            );
        });
    });
    
    //
    //--- pbs.Date Tests for the string generation functions  -------------
    //
    QUnit.module(
        'String Generation Functions',
        {
            before: function(){ // prep sample objects for use in all tests
                this.dl0ce = new pbs.Date(2017, 2, 3); // leading zeros CE
                this.dnl0ce = new pbs.Date(2017, 10, 11); // no leading zeros CE
                this.dl0bce = new pbs.Date(-4, 2, 3); // leading zeros BCE
                this.dnl0bce = new pbs.Date(-10, 11, 12); // no leading zeros BCE
                this.dfmce = new pbs.Date(300, 10, 11); // first millenium CE (less then 4 digits)
                this.dy0 = new pbs.Date(0, 10, 11); // year 0
            }
        },
        function(){
            // test the basic toString()
            QUnit.test('.toString()', function(a){
                a.expect(6);
                a.strictEqual(this.dl0ce.toString(), '2017-02-03', 'CE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0ce.toString(), '2017-10-11', 'CE date with no leading zeros renders correctly');
                a.strictEqual(this.dl0bce.toString(), '-0004-02-03', 'BCE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0bce.toString(), '-0010-11-12', 'BCE date with no leading zeros renders correctly');
                a.strictEqual(this.dfmce.toString(), '0300-10-11', 'First-millenium CE date renders correctly');
                a.strictEqual(this.dy0.toString(), '0000-10-11', 'Year 0 renders correctly');
            });
            
            // test .international()
            QUnit.test('.international()', function(a){
                a.expect(6);
                a.strictEqual(this.dl0ce.international(), '2017-02-03', 'CE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0ce.international(), '2017-10-11', 'CE date with no leading zeros renders correctly');
                a.strictEqual(this.dl0bce.international(), '-0004-02-03', 'BCE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0bce.international(), '-0010-11-12', 'BCE date with no leading zeros renders correctly');
                a.strictEqual(this.dfmce.international(), '0300-10-11', 'First-millenium CE date renders correctly');
                a.strictEqual(this.dy0.international(), '0000-10-11', 'Year 0 renders correctly');
            });
            
            // test .american()
            QUnit.test('.american()', function(a){
                a.expect(6);
                a.strictEqual(this.dl0ce.american(), '2/3/2017', 'CE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0ce.american(), '10/11/2017', 'CE date with no leading zeros renders correctly');
                a.strictEqual(this.dl0bce.american(), '2/3/5BC', 'BCE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0bce.american(), '11/12/11BC', 'BCE date with no leading zeros renders correctly');
                a.strictEqual(this.dfmce.american(), '10/11/300', 'First-millenium CE date renders correctly');
                a.strictEqual(this.dy0.american(), '10/11/1BC', 'Year 0 renders correctly');
            });
            
            // test .european()
            QUnit.test('.european()', function(a){
                a.expect(6);
                a.strictEqual(this.dl0ce.european(), '03-02-2017', 'CE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0ce.european(), '11-10-2017', 'CE date with no leading zeros renders correctly');
                a.strictEqual(this.dl0bce.european(), '03-02-5BCE', 'BCE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0bce.european(), '12-11-11BCE', 'BCE date with no leading zeros renders correctly');
                a.strictEqual(this.dfmce.european(), '11-10-300', 'First-millenium CE date renders correctly');
                a.strictEqual(this.dy0.european(), '11-10-1BCE', 'Year 0 renders correctly');
            });
            
            // test .english()
            QUnit.test('.english()', function(a){
                a.expect(22);
                
                // basic tests
                a.strictEqual(this.dl0ce.english(), '3rd of February 2017', 'CE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0ce.english(), '11th of October 2017', 'CE date with no leading zeros renders correctly');
                a.strictEqual(this.dl0bce.english(), '3rd of February 5BCE', 'BCE date with leading zeros renders correctly');
                a.strictEqual(this.dnl0bce.english(), '12th of November 11BCE', 'BCE date with no leading zeros renders correctly');
                a.strictEqual(this.dfmce.english(), '11th of October 300', 'First-millenium CE date renders correctly');
                a.strictEqual(this.dy0.english(), '11th of October 1BCE', 'Year 0 renders correctly');
                
                // test ordinals
                var d = new pbs.Date(2017, 1, 1);
                a.strictEqual(d.english(), '1st of January 2017', '1st ordinal renders correctly');
                d.day(2);
                a.strictEqual(d.english(), '2nd of January 2017', '2nd ordinal renders correctly');
                d.day(3);
                a.strictEqual(d.english(), '3rd of January 2017', '3rd ordinal renders correctly');
                d.day(4);
                a.strictEqual(d.english(), '4th of January 2017', '4th ordinal renders correctly');
                
                // test month renderings
                d.day(5);
                a.strictEqual(d.english(), '5th of January 2017', 'January renders correctly');
                d.month(2);
                a.strictEqual(d.english(), '5th of February 2017', 'February renders correctly');
                d.month(3);
                a.strictEqual(d.english(), '5th of March 2017', 'March renders correctly');
                d.month(4);
                a.strictEqual(d.english(), '5th of April 2017', 'April renders correctly');
                d.month(5);
                a.strictEqual(d.english(), '5th of May 2017', 'May renders correctly');
                d.month(6);
                a.strictEqual(d.english(), '5th of June 2017', 'June renders correctly');
                d.month(7);
                a.strictEqual(d.english(), '5th of July 2017', 'July renders correctly');
                d.month(8);
                a.strictEqual(d.english(), '5th of August 2017', 'August renders correctly');
                d.month(9);
                a.strictEqual(d.english(), '5th of September 2017', 'September renders correctly');
                d.month(10);
                a.strictEqual(d.english(), '5th of October 2017', 'October renders correctly');
                d.month(11);
                a.strictEqual(d.english(), '5th of November 2017', 'November renders correctly');
                d.month(12);
                a.strictEqual(d.english(), '5th of December 2017', 'December renders correctly');
            });
        }
    );
    
    //
    //--- pbs.Date Tests for the comparison functions  ------------------------
    //
    QUnit.module(
        'Comparison Functions',
        {
            before: function(){ // prep sample objects for use in all tests
                this.d0 = new pbs.Date(2000, 10, 5);
                this.d1 = new pbs.Date(2000, 10, 5);
                this.d2 = new pbs.Date(2000, 10, 6);    
                this.d3 = new pbs.Date(2000, 11, 5);
                this.d4 = new pbs.Date(2001, 10, 4);
            }
        },
        function(){
            // test basic .equals()
            QUnit.test('.equals()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(dtp){
                    a.strictEqual(that.d0.equals(DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' returns false');
                });
                a.strictEqual(this.d0.equals(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Date returns false');
                
                // test with legal input
                a.strictEqual(this.d0.equals(this.d1), true, 'equal dates return true');
                a.strictEqual(this.d1.equals(this.d2), false, 'earlier to later returns false');
                a.strictEqual(this.d4.equals(this.d3), false, 'later to earlier returns false');
            });
            
            // test static pbs.Date.areEqual()
            QUnit.test('pbs.Date.areEqual()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect((mustBeFalse.length * 3) + 8);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(dtp){
                    a.strictEqual(pbs.Date.areEqual(DUMMY_DATA[dtp].val, that.d1), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as first argument returns false');
                    a.strictEqual(pbs.Date.areEqual(that.d1, DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as second argument returns false');
                    a.strictEqual(pbs.Date.areEqual(that.d0, that.d1, DUMMY_DATA[dtp].val), false, 'calling with ' + DUMMY_DATA[dtp].desc + ' as third argument returns false');
                });
                a.strictEqual(pbs.Date.areEqual(DUMMY_DATA.obj_proto.val, this.d1), false, 'calling with a prototyped object that does not have the prototype pbs.Date as the first argumemt returns false');
                a.strictEqual(pbs.Date.areEqual(this.d1, DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Date as the second argumemt returns false');
                a.strictEqual(pbs.Date.areEqual(this.d0, this.d1, DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Date as the third argumemt returns false');
                
                // test with legal inputs
                a.strictEqual(pbs.Date.areEqual(this.d0, this.d1), true, 'two equal dates returns true');
                a.strictEqual(pbs.Date.areEqual(this.d0, this.d1, this.d1.clone()), true, 'three equal dates returns true');
                a.strictEqual(pbs.Date.areEqual(this.d1, this.d2), false, 'two different dates returns false');
                a.strictEqual(pbs.Date.areEqual(this.d0, this.d1, this.d2), false, 'two equal dates and a different date returns false');
                a.strictEqual(pbs.Date.areEqual(this.d1, this.d2, this.d3), false, 'three different dates returns false');
            });
            
            // test .compareTo()
            QUnit.test('.compareTo()', function(a){
                // collect references to all the types that must return NaN
                var mustBeNaN = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeNaN.length + 4);
                
                // test with bogus input
                var that = this;
                mustBeNaN.sort().forEach(function(tn){
                    a.ok(isNaN(that.d1.compareTo(DUMMY_DATA[tn].val)), 'comparing to ' + DUMMY_DATA[tn].desc + ' returns NaN');
                });
                a.ok(isNaN(that.d1.compareTo(DUMMY_DATA.obj_proto.val)), 'comparing to object with prototype other than pbs.Date returns NaN');
                
                // test with legal inputs
                a.strictEqual(this.d0.compareTo(this.d1), 0, 'equal dates return 0');
                a.strictEqual(this.d1.compareTo(this.d2), -1, 'earlier to later returns -1');
                a.strictEqual(this.d4.compareTo(this.d3), 1, 'later to earlier returns 1');
            });
            
            // test .isBefore()
            QUnit.test('.isBefore()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(tn){
                    a.strictEqual(that.d0.isBefore(DUMMY_DATA[tn].val), false, 'calling with ' + DUMMY_DATA[tn].desc + ' returns false');
                });
                a.strictEqual(this.d0.isBefore(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Date returns false');
                
                // test with legal inputs
                a.strictEqual(this.d0.isBefore(this.d1), false, 'equal dates return false');
                a.strictEqual(this.d1.isBefore(this.d2), true, 'earlier to later returns true');
                a.strictEqual(this.d4.isBefore(this.d3), false, 'later to earlier returns false');
            });
            
            // test .isAfter()
            QUnit.test('.isAfter()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('obj');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 4);
                
                // test with bogus input (expecting false for all bogus input)
                var that = this;
                mustBeFalse.sort().forEach(function(tn){
                    a.strictEqual(that.d0.isAfter(DUMMY_DATA[tn].val), false, 'calling with ' + DUMMY_DATA[tn].desc + ' returns false');
                });
                a.strictEqual(this.d0.isAfter(DUMMY_DATA.obj_proto.val), false, 'calling with a prototyped object that does not have the prototype pbs.Date returns false');
                
                // test with legal inputs
                a.strictEqual(this.d0.isAfter(this.d1), false, 'equal dates return false');
                a.strictEqual(this.d1.isAfter(this.d2), false, 'earlier to later returns false');
                a.strictEqual(this.d4.isAfter(this.d3), true, 'later to earlier returns true');
            });
        }
    );
    
    //
    //--- pbs.Date Leap Year function tests -----------------------------------
    //
    QUnit.module(
        'Leap-year functions', {},
        function(){
            // test pbs.Date.isLeapYear()
            QUnit.test('pbs.Date.isLeapYear()', function(a){
                // collect references to all the types that must return false
                var mustBeFalse = dummyBasicTypesExcept('num');
                
                // now that we know how many type tests there will be, set expect
                a.expect(mustBeFalse.length + 6);
                
                // test with bogus input (expecting false for all bogus input)
                mustBeFalse.sort().forEach(function(tn){
                    a.strictEqual(pbs.Date.isLeapYear(DUMMY_DATA[tn].val), false, 'calling with ' + DUMMY_DATA[tn].desc + ' returns false');
                });
                a.strictEqual(pbs.Date.isLeapYear(Math.PI), false, 'calling with a non-integer number returns false');
                
                // make sure integer strings are allowed
                a.strictEqual(pbs.Date.isLeapYear('1996'), true, 'integers as strings are accepted');
                
                // test with outputs with legal inputs
                a.strictEqual(pbs.Date.isLeapYear(2001), false, '2001 returns false (year not divisible by 4)');
                a.strictEqual(pbs.Date.isLeapYear(2004), true, '2004 returns year (non-century year divisible by 4)');
                a.strictEqual(pbs.Date.isLeapYear(1900), false, '1900 returns false (century not divisible by 400)');
                a.strictEqual(pbs.Date.isLeapYear(2000), true, '2000 returns true (century divisible by 400)');
            });
            
            // test pbs.Date.leapYearsBetween()
            QUnit.test('pbs.Date.leapYearsBetween()', function(a){
                // collect references to all the types that must throw an error
                var mustThrow = dummyBasicTypesExcept('num');
                
                // now that we know how many type tests there will be, set expect
                a.expect((mustThrow.length * 2) + 7);
                
                // test with bogus inputs (expecting an error to be thrown)
                mustThrow.sort().forEach(function(tn){
                    a.throws(
                        function(){
                            var a = pbs.Date.leapYearsBetween(DUMMY_DATA[tn].val, 2000);
                        },
                        Error,
                        'throws an error when passed ' + DUMMY_DATA[tn].desc + ' as the first argument'
                    );
                    a.throws(
                        function(){
                            var a = pbs.Date.leapYearsBetween(2000, DUMMY_DATA[tn].val);
                        },
                        Error,
                        'throws an error when passed ' + DUMMY_DATA[tn].desc + ' as the second argument'
                    );
                });
                a.throws(
                    function(){
                        var a = pbs.Date.leapYearsBetween(Math.PI, 2000);
                    },
                    Error,
                    'throws an error when passed a non-integer number as the first argument'
                );
                a.throws(
                    function(){
                        var a = pbs.Date.leapYearsBetween(2000, Math.PI);
                    },
                    Error,
                    'throws an error when passed a non-integer number as the second argument'
                );
                
                // make sure integers as strings are accepted
                a.ok((function(){ pbs.Date.leapYearsBetween('2000', '2003'); return true; })(), 'integers as strings are accepted for both arguments');
                
                // test outputs with legal inputs
                a.deepEqual(pbs.Date.leapYearsBetween(2001, 2003), [], 'range without leap years returns empty array');
                a.deepEqual(pbs.Date.leapYearsBetween(2000, 2008), [2000, 2004, 2008], 'range starting and ending on leap years returns array including both extremes');
                a.deepEqual(pbs.Date.leapYearsBetween(1999, 2009), [2000, 2004, 2008], 'range starting and ending on non-leap-years returns expected array');
                a.deepEqual(pbs.Date.leapYearsBetween(2009, 1999), [2000, 2004, 2008], 'range also works when specified with smallest year first');
            });
        }
    );
});