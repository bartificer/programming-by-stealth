# Hello World Mark II

This is a dummy project for use as an example is instalment 104 of the [Programming by Stealth](https://pbs.bartificer.net/) blog/podcast series.

This project contains a single HTML 5 web pages that says hello to the world.