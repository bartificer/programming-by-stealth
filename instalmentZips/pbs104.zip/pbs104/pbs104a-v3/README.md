# Hello World Mark II

This is a dummy project for use as an example in instalment 104 of the [Programming by Stealth](https://pbs.bartificer.net/) blog/podcast series.

This project contains a single HTML 5 web pages that says hello to the world.

This project embeds a copy of the open source Bootstrap 4.5 CSS stylesheet created by [Twitter Inc.](https://twitter.com/) and released under the [MIT License](https://github.com/twbs/bootstrap/blob/main/LICENSE).