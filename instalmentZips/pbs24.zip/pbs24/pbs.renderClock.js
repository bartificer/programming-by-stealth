/**
* @overview A simple single-function API for inserting a clock into a web page that shows the current time in a give timezone.

This single-function API is consists solely of the function {@link pbs.renderClock} within the {@link pbs} namespace.

* @requires jQuery
* @requires moment
* @requires moment-timezone
* @author Bart Busschots
*/

// set up the PBS namespace
/**
* APIs related to the [Programming by Stealth podcast/blog series](http://bartb.ie/pbs) are grouped under this namespace.
* @namespace
*/
var pbs = pbs ? pbs : {};

// define our API within a self-executing anonymous function
(function(pbs){

  /**
  * Converts a given span into a clock showing the current time in a given time zone.
  * 
  * **NOTE** this function should not be called before the DOM is ready.
  * @param {jQuery} $span - a jQuery object representing the span to be converted into a clock.
  * This argument must be a jQuery representing exactly one element, and that element must be a span.
  * @param {string} tz - a string containing a valid timezone (with any spaces replaced with `_` characers), e.g. `America/Los_Angeles` or `Europe/Dublin`.
  * @returns {jQuery} A reference to `$span`.
  * @throws {Error} A generic error is thrown if and invalid value is passed for `$span`.
  * @example
  * pbs.renderClock($('#example-clock'), 'Europe/Brussels');
  */
  pbs.renderClock = function($span, tz){
    // validate the arguments
    if(!(typeof $span === 'object' && $span instanceof jQuery && $span.length === 1 && $span.is('span'))){
    	throw new Error('the first argument must be a jQuery object representing exactly one span element');
    }
    
    //
    // YOUR CODE HERE
    //
    
    // return the span
    return $span;
  };
})(pbs);