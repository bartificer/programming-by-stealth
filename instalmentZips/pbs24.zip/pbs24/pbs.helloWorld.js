/**
* @overview A simple sample API that contains just one function. Everything is contained within the {@link pbs} namespace.
* @author Bart Busschots
*/

// set up the PBS namespace
/**
* APIs related to the [Programming by Stealth podcast/blog series](http://bartb.ie/pbs) are grouped under this namespace.
* @namespace
*/
var pbs = pbs ? pbs : {};

// define our API within a self-executing anonymous function
(function(pbs){
  // Define a 'private' variable that
  // will not exist in the global scope
  var theString = "Hello World!";

  /**
  * Alerts the message *Hello World!*.
  * @example
  * pbs.helloWorld();
  */
  pbs.helloWorld = function(){
    window.alert(theString);
  };
})(pbs);