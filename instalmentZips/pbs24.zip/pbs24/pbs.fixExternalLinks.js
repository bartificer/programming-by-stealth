/**
* @overview A simple single-function API for fixing external links. An external link is a link that goes to a domain outside the current site. A link is fixed by making sure it has a `target` of `_blank` and a `rel` of `noopener`. By default, an icon is also appended to show that the link opens in a new window/tab, but this can be suppressed.

This single-function API is consists solely of the function {@link pbs.fixExternalLinks} within the {@link pbs} namespace.

* @requires jQuery
* @requires URI
* @author Bart Busschots
*/

// set up the PBS namespace
/**
* APIs related to the [Programming by Stealth podcast/blog series](http://bartb.ie/pbs) are grouped under this namespace.
* @namespace
*/
var pbs = pbs ? pbs : {};

// define our API within a self-executing anonymous function
(function(pbs){
  // define a 'private' variable containing the default configuration
  var defaults = {
  	injectIcons: true,
  	iconSrc: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAg9JREFUeNqkU89rE0EYfbubjZu4pLWSipfGqlQpelARb7YgHhTBgwfRRVCKepSCRYoHLyJi/wM96KW5CR48qYfmUKjStMGghZY2irHNNptoStptsj/Gb6Z0cRs95cGbGXbe9775Zr+RGGNoBxE+nLv9EYqiiA89PQfELEnSBHHgX0GUNPNidO9gYPA3THMFup6AqqrPj6TUgYe3ki0GNx4VA2N552aj0UClUiZa6U+fy8adx4tYrTohTb1eR8iAMf+K53lLRLbNTt1nutYcX/xuoWRthgzW1mqhenD66rulyVmL+b4fcHauys5ce89mvv5iHNNfKmx5dUOsSc8nESuG/ktvRNZmsymYn7fYxbsfWJaCOKgUxjXnh0SgWG8byFt1O3BdFxSMb8UaXr5ewJN7x9F/MI6pXAnG/Qkk90RR+FEzjJGM0O+4A1kYVH/bmJwxcf3CPiQ7PGTzJTwYm8az4T7SSPB9KT2VswxaZ0IGiqLBcTwsmxs40RdHV0JF0Wxg/O1PjA4dwrHDHVgp+6SL8Q5JEwdDjRSN6nR8D8nOXSSSsL7JkF+wcfNyCt1dKm8qoeFwXYWSrYc7UdMSdEQVsVgEns/IwMHZU93Q40og5JotJOgOai0Ghdy833vyaAwR+jOp/RpkWQpE2TlbaFrNghJ2jzx9ZY8Bdu9/3kyBa6jhWjakdl+jjDbxR4ABAPjFI5E3WpRkAAAAAElFTkSuQmCC',
  	iconClass: 'pbs-externalLinkIcon',
  	ignoreClass: 'pbs-ignore',
  	noIconClass: 'pbs-noIcon',
  	subDomainsLocal: true,
  	localDomains: []
  };

  /**
  * Scans a document, or part of a document, for links, and alters all external links in the following way:
  * * sets the `target` attribute to `_blank` so they open in new windows/tabs.
  * * sets the `rel` attribute to `noopener` to prevent abuse of the JS `opener` object by the linked-to site.
  * * injects an icon after the link (unless instructed not to).
  *
  * Because there are a number of possible legal values for the `rel` attribute, and because multiple values are allowed on this attribute (space-delimited),
  * this function checks to see if there is already a value before changing it.
  * 
  * **NOTE** this function should not be called before the DOM is ready.
  * @param {?jQuery} [$container=$(document)] - a jQuery object representing the container(s) within which to search for links. Defaults to the entire document.
  * @param {Object} [config] - a plain object containing optional configuration values.
  * @param {boolean} [config.injectIcons=true] - whether or not to inject icons. Set to `false` to prevent icons being injected.
  * @param {string} [config.iconSrc] - the value of the `src` attribute of the `img` tag for the icon. Defaults to the data URL for the default icon.
  * @param {string} [config.iconClass=pbs-externalLinkIcon] - the CSS class that will be added to all icons created by this function.
  * @param {string} [config.ignoreClass=pbs-ignore] - `a` tags with this CSS class will be ignored.
  * @param {string} [config.noIconClass=pbs-noIcon] - `a` tags with this CSS class will be processed, but will not have an icon injected after them.
  * @param {boolean} [config.subDomainsLocal=true] - whether or not sub domains of the page's domain should be considered local.
  * @param {string[]} [config.localDomains=[]] - an array of strings representing other domains that should be considered local.
  * @returns {jQuery} A jQuery object representing the container within which links were processed, i.e. `$container` or `$(document)`.
  * @throws {Error} A generic error is thrown if and invalid value is passed for `$container`.
  * @example
  * // apply the default changes to all external links in the document
  * pbs.fixExternalLinks();
  *
  * // apply the default changes to all external links within the main tag
  * pbs.fixExternalLinks($('main'));
  * 
  * // apply set the target and rel attributes on all external links in the
  * // document, but do not inject any icons
  * pbs.fixExternalLinks(null, {injectIcons: false});
  */
  pbs.fixExternalLinks = function($container, config){
    // get the container to search
    if($container && !($container instanceof jQuery)){
    	throw new Error('if defined, the first argument must be a jQuery object');
    }else{
    	$container = $(document);
    }
    
    // build a final config object by combining everything passed with the defaults
    var finConf = {};
    if(typeof config === 'object'){
    	// a config was passed, so process each key individually
    	finConf = {
    		injectIcons: typeof config.injectIcons === 'boolean' ? config.injectIcons : defaults.injectIcons,
    		iconSrc: typeof config.iconSrc === 'string' ? config.iconSrc : defaults.iconSrc,
    		iconClass: typeof config.iconClass === 'string' ? config.iconClass : defaults.iconClass,
    		ignoreClass: typeof config.ignoreClass === 'string' ? config.ignoreClass : defaults.ignoreClass,
    		noIconClass: typeof config.noIconClass === 'string' ? config.noIconClass : defaults.noIconClass,
    		subDomainsLocal: typeof config.subDomainsLocal === 'boolean' ? config.subDomainsLocal : defaults.subDomainsLocal,
    		localDomains: typeof config.localDomains === 'object' && config.localDomains instanceof Array ? config.localDomains : defaults.localDomains
    	};
    }else{
    	// no config was passed, so use all the defaults
    	finConf = defaults;
    }
    
    // create a URI object representing the URL of the page
    var pageURI = new URI();
    
    // get the parts of the page's domain, and reverse them so they have the TLD first
    var pageDomainParts = pageURI.hostname().split('.').reverse();
    
    // process all the links
    $('a').each(function(){
    	var $a = $(this);
    	
    	// skip links with the approrpiate class for marking them to be ignored
    	if($a.is('.' + finConf.ignoreClass)){
    		return;
    	}
    	
    	// create a URI object representing the target of this link
    	var aURI = $a.uri();
    	
    	// skip relative links
    	if(aURI.is('relative')){
    		return;
    	}
    	
    	// skip links where the domains match exactly
    	if(pageURI.hostname() == aURI.hostname()){
    		return;
    	}
    	
    	// if subdomains are to be considered local, check
    	// if the link is to a sub domain, and skip if it is
    	if(finConf.subDomainsLocal){
    		// break the link's domain into parts, and reverse them so the TLD is first
    		var linkDomainParts = aURI.hostname().split('.').reverse();
    		
    		// the link domain can only be a sub domain if it is longer than the page domain
    		if(linkDomainParts.length > pageDomainParts.length){
    			// make sure that all domain parts in the page are in the link
    			var plausiblySubDom = true;
    			for(var i = 0; plausiblySubDom && i < pageDomainParts.length; i++){
    				if(pageDomainParts[i] != linkDomainParts[i]){
    					plausiblySubDom = false;
    				}
    			}
    			// if we got here and plausiblySubDom is still true, we have a sub domain, so skip
    			if(plausiblySubDom){
    				return;
    			}
    		}
    	}
    	
    	// if there are additional domains to be considered local, test against each
    	if(finConf.localDomains.length){
    		for(var i = 0; i < finConf.localDomains.length; i++){
    			if(aURI.hostname() == finConf.localDomains[0]){
    				return;
    			}
    		}
    	}
    	
    	// if we got here, the link needs to be transformed
    	
    	// set the target
    	$a.attr('target', '_blank');
    	
    	// deal with the rel attribute - first check if there already is one
    	if($a.attr('rel')){
    		// add noopener to the end unless it is already in there
    		if(!$a.attr('rel').match(/\bnoopener\b/)){
    			$a.attr('rel', $a.attr('rel') + ' noopener');
    		}
    	}else{
    		// there is no current rel value, so set one
    		$a.attr('re', 'noopener');
    	}
    	
    	// inject an icon if appropriate
    	if(finConf.injectIcons && !$a.is('.' + finConf.noIconClass)){
    		// create the icon
    		var $icon = $('<img />').attr('src', finConf.iconSrc).attr('alt', 'External Link Icon');
    		$icon.attr('title', 'Link Opens in New Tab');
    		$icon.addClass(finConf.iconClass);
    		$icon.css({
    			verticalAlign: 'middle',
    			marginLeft: '1px',
    			marginRight: '1px'
    		});
    		
    		// inject the icon into the DOM
    		$a.after($icon);
    	}
    });
    
    // return the container
    return $container;
  };
})(pbs);