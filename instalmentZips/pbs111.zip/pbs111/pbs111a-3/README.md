# Hello World!!!

This is a dummy project for use as an example in instalments 104 through 111 of the [Programming by Stealth](https://pbs.bartificer.net/) blog/podcast series.

This project contains a single HTML 5 web page that says hello to the world.

This project embeds a copy of the open source Bootstrap 4.5 CSS & Javascript library created by [Twitter Inc.](https://twitter.com/). To meet Bootstrap 4's requirements this project also embeds [jQuery](https://jquery.com/) and [Popper.js](https://popper.js.org/). Finally, this project embeds a copy of the [Moment.js](https://momentjs.com) library. All of these open source libraries are released under the [MIT License](https://github.com/twbs/bootstrap/blob/main/LICENSE).

## About the Authors
[Bart](https://bart.busschots.ie/) writes the blog posts, and Bart & [Allison](https://www.podfeet.com/) record the matching podcast episodes.