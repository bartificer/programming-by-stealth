#!/usr/bin/env node

// import the default export with a name of our choosing
import showSleeps from './s2xmas.mjs';

// call the imported function
showSleeps();