This demo is part of a series of text tutorials with matching podcast episodes (or podcast episodes with matching turtials, depending on your POV).
You can find the full series at [pbs.bartificer.net](https://pbs.bartificer.net).

If this was not a contrived example there would be much more text here 🙂