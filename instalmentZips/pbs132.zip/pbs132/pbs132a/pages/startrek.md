Star Trek is a vast and sprawling franchise which started with a short-lived scifi series by Gene Rodenberry in 1966. For more see [the Star Trek Wikipedia entry](https://en.wikipedia.org/wiki/Star_Trek).

Right from the original 1966 series, the Star Trek universe has always had replictors, devices for creating food from raw energy.