#!/usr/bin/env bash

echo "You passed $# args"