#!/usr/bin/env bash

echo "The Even Numbers from zero to twenty:"
for n in $(seq 0 2 20)
do
    echo "* $n"
done