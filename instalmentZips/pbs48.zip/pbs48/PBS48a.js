// define the class
class Explainer{
	constructor(n){
		// initialise an instance variable
		this.instanceName = n ? n : 'Jane Doe';
	}
	
	// add an instance function
	instanceFn(){
		console.log(`instance name = '${this.instanceName}'`);
	}
	
	// add a static function
	static staticFn(){
		console.log(`static name = '${this.staticName}'`);
	}
}

// add a static property to the class
Explainer.staticName = 'the explainer class';

// demo static property and function
console.log(Explainer.staticName);
Explainer.staticFn();

// outputs:
// --------
// the explainer class
// static name = 'the explainer class'

// demo error
// Explainer.instanceFn();
// Throws Error:
// -------------
// TypeError: Explainer.instanceFn is not a function

// demo instance property and function
const firstInstance = new Explainer('Alice');
const secondInstance = new Explainer('Bob');
console.log(firstInstance.instanceName);
firstInstance.instanceFn();
console.log(secondInstance.instanceName);
secondInstance.instanceFn();

// outputs:
// --------
// Alice
// instance name = 'Alice'
// Bob
// instance name = 'Bob'

// demo error
//firstInstance.staticFn();
// Throws Error:
// -------------
// TypeError: firstInstance.staticFn is not a function

// define another explainer class
class BetterExplainer{
	constructor(n){
		// set an instance property named myName
		this.myName = n ? n : 'Jane Doe';
	}
	
	// an instance function to log the instance's name
	logMyName(){
		console.log(`instance name is '${this.myName}'`);
	}
	
	// a static function to log the class's name
	static logMyName(){
		console.log(`static name is '${this.myName}'`);
	}
}

// set a static property named myName
BetterExplainer.myName = 'the better explainer class';

// demo static property and function
console.log(BetterExplainer.myName);
BetterExplainer.logMyName();

// outputs:
// --------
// the better explainer class
// static name is 'the better explainer class'

// demo instance property and function
const firstBetterInstance = new BetterExplainer('Alicia');
const secondBetterInstance = new BetterExplainer('Robbert');
console.log(firstBetterInstance.myName);
firstBetterInstance.logMyName();
console.log(secondBetterInstance.myName);
secondBetterInstance.logMyName();

// outputs:
// --------
// Alicia
// instance name is 'Alicia'
// Robbert
// instance name is 'Robbert'

// demonstrate the name property
console.log(Explainer.name);
console.log(BetterExplainer.name);

// outputs:
// --------
// Explainer
// BetterExplainer

// declare another explainer class
class EvenBetterExplainer{
	constructor(n){
		// set an instance property named myName
		this.myName = n ? n : 'Jane Doe';
	}
		
	// an instance function to log the instance's name
	logMyName(){
		console.log(`instance name is '${this.myName}'`);
	}
		
	// a static function to log the class's name
	static logClassName(){
		console.log(`my class name is '${this.name}'`);
	}
}

// demo the class name logging function
EvenBetterExplainer.logClassName();

// outputs:
// --------
// my class name is 'EvenBetterExplainer'

// add a sub-class
class PointlessSubClass extends EvenBetterExplainer{
	constructor(n){
		super(n);
	}
}

// demo inherited static function and this placeholder behaviour
PointlessSubClass.logClassName();

// outputs:
// --------
// my class name is 'PointlessSubClass'

// declare a final explainer class
class BestExplainer{
	constructor(n){
		// set an instance property named myName
		this.myName = n ? n : 'Jane Doe';
	}
		
	// an instance function to log the instance's name
	logMyName(){
		console.log(`instance name is '${this.myName}'`);
	}
	
	// an instance function to log the instance's class
	logClassName(){
		console.log(`${this.myName} is an instance of the class '${this.constructor.name}'`);
	}
		
	// a static function to log the class's name
	static logClassName(){
		console.log(`my class name is '${this.name}'`);
	}
}

// demo the logClassName instance function
let bestInstance = new BestExplainer('Allison');
bestInstance.logClassName();

// outputs:
// --------
// Allison is an instance of the class 'BestExplainer'

// create another subclass
class BestSubclass extends BestExplainer{
	constructor(n){
		super(n);
	}
}

// demo the inherited logClassName instance function
let bestSubclassInstance = new BestSubclass('Roberta');
bestSubclassInstance.logClassName();

// outputs:
// --------
// Roberta is an instance of the class 'BestSubclass'