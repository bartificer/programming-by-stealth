<?php
# Set the MIME-Type to text/plain
header('Content-Type: text/plain');

# build the URL
$url = 'http://wttr.in/'.urlencode($_REQUEST['city']).'?format=3';
$url .= $_REQUEST['units'] == 'f' ? '&u' : '&c';

# fetch and output the URL
echo file_get_contents($url);