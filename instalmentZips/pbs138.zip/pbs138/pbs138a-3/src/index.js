// import our custom CSS
import './index.css';

// import jQuery
import $ from 'jquery';

// a jQuery document ready handler
$(()=>{
    $('#world-modifier').text('jQuery');
});