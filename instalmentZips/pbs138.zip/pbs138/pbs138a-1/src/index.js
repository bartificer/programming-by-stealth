// a document ready handler in plain JavaScript (no JQuery)
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('world-modifier').innerText = 'Dynamic';
}, false);