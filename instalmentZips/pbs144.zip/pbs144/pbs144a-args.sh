#!/usr/bin/env bash

echo "I am '$0', my first arg is '$1', and my second is '$2'"