#!/usr/bin/env bash

read -p "What's your name? " name
read -p "What's your favourite friut? " fruit
echo "Hi $name, have some $fruit"'s 🙂'